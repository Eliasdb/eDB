"""Sample Hello World application."""


def hello():
    """Return a friendly greeting."""
    return "Hello tools-invoices-api"
